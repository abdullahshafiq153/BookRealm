<?php
require_once '../app/controllers/BookController.php';
require_once '../app/controllers/UserController.php';

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if ($uri === '/books' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $controller = new BookController();
    $controller->index();
} elseif ($uri === '/profile' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $controller = new UserController();
    $controller->profile();
} elseif ($uri === '/logout' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $controller = new UserController();
    $controller->logout();
} else {
    echo "404 Not Found";
}
