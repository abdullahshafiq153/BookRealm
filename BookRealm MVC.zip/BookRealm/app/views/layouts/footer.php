<footer class="bg-gray-800 text-white py-4">
    <div class="container mx-auto text-center">
        <p>BookRealm &copy; 2024. All rights reserved.</p>
    </div>
</footer>

<script>
    document.getElementById('toggleButton').addEventListener('click', function() {
        var navLinks = document.getElementById('navLinks');
        navLinks.classList.toggle('hidden');
    });
</script>
</body>
</html>
