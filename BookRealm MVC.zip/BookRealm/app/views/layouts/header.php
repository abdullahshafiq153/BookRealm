<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BookRealm</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 text-gray-900">
    <nav class="bg-white shadow-md">
        <div class="container mx-auto flex justify-between items-center py-4">
            <a href="#" class="text-2xl font-bold text-blue-600">BookRealm</a>
            <div class="flex items-center space-x-4">
                <ul class="hidden md:flex space-x-4">
                    <li><a href="../MyList/mylist.php" class="text-gray-700 hover:text-blue-600">My List</a></li>
                    <li><a href="../MyBooks/mybooks.php" class="text-gray-700 hover:text-blue-600">My Books</a></li>
                </ul>
                <div class="flex items-center space-x-4">
                    <a href="../SignOut/logout.php" class="text-gray-700 hover:text-blue-600">Sign Out</a>
                    <a href="../MyProfile/profilepage.php" class="flex items-center">
                        <img src="../images/icons/user-basecolor.png" alt="UserAccount" class="w-8 h-8">
                    </a>
                </div>
                <button id="toggleButton" class="md:hidden flex flex-col space-y-1">
                    <span class="block w-6 h-0.5 bg-gray-700"></span>
                    <span class="block w-6 h-0.5 bg-gray-700"></span>
                    <span class="block w-6 h-0.5 bg-gray-700"></span>
                </button>
            </div>
        </div>
    </nav>
