<?php require '../app/views/layouts/header.php'; ?>

<div class="container mx-auto p-4">
    <h1 class="text-4xl font-bold text-center my-8">Welcome to BookRealm!</h1>
    <div class="flex justify-center my-4">
        <input type="text" name="Search" placeholder="Search from hundreds of books in BookRealm" class="w-full md:w-1/2 p-2 border border-gray-300 rounded">
    </div>
    <p class="text-center text-gray-700 mb-8">Check out our latest books</p>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php while ($row = mysqli_fetch_assoc($books)) : ?>
            <?php $isLiked = $row['is_liked'] ? true : false; ?>
            <div class="bg-white p-4 rounded shadow-md">
                <img src="../images/<?php echo $row['title']; ?>.jpg" alt="<?php echo $row['title']; ?>" class="w-full h-48 object-cover rounded">
                <h3 class="text-xl font-bold my-2"><?php echo $row['title']; ?></h3>
                <p class="text-gray-600">Author: <?php echo $row['author']; ?></p>
                <p class="text-gray-600">Genre: <?php echo $row['genre']; ?></p>
                <button class="like-button mt-2" data-book-id="<?php echo $row['id']; ?>" data-is-liked="<?php echo $isLiked ? 'true' : 'false'; ?>">
                    <img src="../images/icons/<?php echo $isLiked ? 'heart-filled.png' : 'heart.png'; ?>" alt="Like" class="w-6 h-6">
                </button>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php require '../app/views/layouts/footer.php'; ?>
