<?php

class Book {
    private $conn;

    public function __construct() {
        global $conn;
        $this->conn = $conn;
    }

    public function getAllBooks() {
        $sql = "SELECT * FROM books";
        $result = $this->conn->query($sql);
        return $result;
    }
}
