<?php
require_once '../app/models/Book.php';

class BookController {
    public function index() {
        $bookModel = new Book();
        $books = $bookModel->getAllBooks();
        require '../app/views/books/index.php';
    }
}
